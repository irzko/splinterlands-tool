from splint import Launcher
Launcher.menu()